import argparse
import getpass
import ssl

import atexit

from pyVim.task import WaitForTask
from pyVim.connect import Disconnect, SmartConnect

from pyVmomi import vim


def get_args():
    parser = argparse.ArgumentParser(description='Arguments for talking to vCenter')

    parser.add_argument('-s', '--host', required=True, action='store', help='vSphere service to connect to')

    parser.add_argument('-u', '--user', required=True, action='store', help='User name to use')

    parser.add_argument('-p', '--password', required=True, action='store', help='Password to use')

    parser.add_argument('-v', '--vm-name', required=True, action='store', help='name of the vm')

    args = parser.parse_args()

    if not args.password:
        args.password = getpass.getpass(prompt='Enter password')

    return args


def get_obj(content, vimtype, name):
    """
    Get vcenter object

    Args:
        content (vm_object): content object
        vimtype (vm_object) : object type
        name (str): vm name

    Returns:
        Object: Returns a object in given vcenter type
    """
    vm_object = None
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
    for c in container.view:
        if c.name == name:
            vm_object = c
            break
    return vm_object


def cpu_hot_plug(VM):
    print("Found: {0}".format(VM.name))
    print("The current powerState is: {0}".format(VM.runtime.powerState))
    if format(VM.runtime.powerState) == "poweredOn":
        print("Attempting to power off {0}".format(VM.name))
        TASK = VM.PowerOffVM_Task()
        WaitForTask(TASK)
        print("{0}".format(TASK.info.state))
    if vim:
        cspec = vim.vm.ConfigSpec()
        cspec.cpuHotRemoveEnabled = True
        TASK = VM.Reconfigure(cspec)
        print("Before cspec.cpuHotAddDisabled")
        WaitForTask(TASK)
        print("After cspec.cpuHotAddDisabled...Done")
        print("Before PowerOn")
        WaitForTask(VM.PowerOn())
        print("PowerOn success.")
    else:
        print("vim object not found")


print("Done.")


def main():
    args = get_args()

    # connect this thing
    context = None
    if hasattr(ssl, "_create_unverified_context"):
        context = ssl._create_unverified_context()
    serviceInstance = SmartConnect(host=args.host, user=args.user, pwd=args.password, sslContext=context)
    # disconnect this thing
    atexit.register(Disconnect, serviceInstance)
    vm = None
    if args.vm_name:
        content = serviceInstance.RetrieveContent()
        vm = get_obj(content, [vim.VirtualMachine], args.vm_name)

    if vm:
        cpu_hot_plug(vm)
    else:
        print "VM not found"


# start this thing
if __name__ == "__main__":
    main()
