#!/usr/bin/env python
# Copyright 2015 Michael Rice <michael@michaelrice.org>
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

from __future__ import print_function
import ssl

import atexit

from pyVim.task import WaitForTask

from pyVim import connect
from pyVim.connect import Disconnect, SmartConnect, GetSi

from pyVmomi import vim

from tools import cli
from tools import tasks

def get_obj(content, vimtype, name):
    """
    Get vcenter object

    Args:
        content (vm_object): content object
        vimtype (vm_object) : object type
        name (str): vm name

    Returns:
        Object: Returns a object in given vcenter type
    """
    vm_object = None
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
    for c in container.view:
        if c.name == name:
            vm_object = c
            break
    return vm_object


def setup_args():

    """Adds additional ARGS to allow the vm name or uuid to
    be set.
    """
    parser = cli.build_arg_parser()
    # using j here because -u is used for user
    parser.add_argument('-j', '--uuid',
                        help='BIOS UUID of the VirtualMachine you want '
                             'to destroy.')
    parser.add_argument('-n', '--name',
                        help='DNS Name of the VirtualMachine you want to '
                             'destroy.')
    parser.add_argument('-i', '--ip',
                        help='IP Address of the VirtualMachine you want to '
                             'destroy')
    parser.add_argument('-v', '--vm',
                        help='VM name of the VirtualMachine you want '
                             'to destroy.')
    parser.add_argument('-m', '--memory',
                        help='No of Memory')

    my_args = parser.parse_args()

    return cli.prompt_for_password(my_args)


def get_obj(content, vimtype, name):

    """Create contrainer view and search for object in it"""
    obj = None
    container = content.viewManager.CreateContainerView(
        content.rootFolder, vimtype, True)
    for c in container.view:
        if name:
            if c.name == name:
                obj = c
                break
        else:
            obj = c
            break

    container.Destroy()
    return obj

args=setup_args()

context = None
if hasattr(ssl, "_create_unverified_context"):
    context = ssl._create_unverified_context()
connection = connect.Connect(args.host,443, args.user,
                                 args.password, sslContext=context)
atexit.register(Disconnect, connection)
content = connection.RetrieveContent()

VM = get_obj(content, [vim.VirtualMachine], args.uuid)

print("Found: {0}".format(VM.name))
#print("The current powerState is: {0}".format(VM.runtime.powerState))
#if format(VM.runtime.powerState) == "poweredOn":
#    print("Attempting to power off {0}".format(VM.name))
#    TASK = VM.PowerOffVM_Task()
#    tasks.wait_for_tasks(content, [TASK])
#    print("{0}".format(TASK.info.state))

if vim:
    cspec = vim.vm.ConfigSpec()
    cspec.memoryMB  = long(args.memory)
    TASK = VM.Reconfigure(cspec)
    WaitForTask(TASK)
    print("its done.")
else:
    print("vim object not found")


print("Done.")
