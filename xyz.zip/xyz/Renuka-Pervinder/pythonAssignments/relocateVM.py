import argparse
import atexit
import ssl

from pyVim.task import WaitForTask
from pyVmomi import vim
from pyVim.connect import SmartConnect, Disconnect
import getpass

"""
migrate vm from one data store to another.
"""
def get_args():
    parser = argparse.ArgumentParser(description='Arguments for talking to vCenter')

    parser.add_argument('-s', '--host', required=True, action='store', help='vSphere service to connect to')

    parser.add_argument('-u', '--user', required=True, action='store', help='User name to use')

    parser.add_argument('-p', '--password', required=True, action='store', help='Password to use')

    parser.add_argument('-v', '--vm-name', required=True, action='store', help='name of the vm')

    parser.add_argument('-eh', '--esx-host', required=True, action='store', help='host machine address')

    parser.add_argument('-d', '--data-store', required=True, action='store', help='New data store')

    args = parser.parse_args()

    if not args.password:
        args.password = getpass.getpass(prompt='Enter password')

    return args


def get_obj(content, vimtype, name):
    """
    Get vcenter object

    Args:
        content (vm_object): content object
        vimtype (vm_object) : object type
        name (str): vm name

    Returns:
        Object: Returns a object in given vcenter type
    """
    vm_object = None
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
    for c in container.view:
        if c.name == name:
            vm_object = c
            break
    return vm_object


def main():
    args = get_args()

    # connect this thing
    context = None
    if hasattr(ssl, "_create_unverified_context"):
        context = ssl._create_unverified_context()
    serviceInstance = SmartConnect(host=args.host, user=args.user, pwd=args.password, sslContext=context)
    # disconnect this thing
    atexit.register(Disconnect, serviceInstance)
    content = serviceInstance.RetrieveContent()
    vm = get_obj(content, [vim.VirtualMachine], args.vm_name)
    esx_host = get_obj(content, [vim.HostSystem], args.esx_host)
    destination_datastore = get_obj(content, [vim.Datastore],
                                    args.data_store)
    # resource_pool = vm.resourcePool

    if vm:
        relocateVM(vm, esx_host, destination_datastore)
    else:
        print "VM not found"


def relocateVM(vm, host, ds):
    relocate_spec = vim.vm.RelocateSpec(datastore=ds, host=host)
    task = vm.Relocate(relocate_spec)
    WaitForTask(task)


# start this thing
if __name__ == "__main__":
    main()
