import argparse
import atexit
import getpass
import ssl
import time

from pyVim.task import WaitForTask
from pyVmomi import vim
from pyVim.connect import Disconnect, SmartConnect


def get_args():
    parser = argparse.ArgumentParser(description='Arguments for talking to vCenter')

    parser.add_argument('-s', '--host', required=True, action='store', help='vSphere service to connect to')

    parser.add_argument('-u', '--user', required=True, action='store', help='User name to use')

    parser.add_argument('-p', '--password', required=True, action='store', help='Password to use')

    parser.add_argument('-v', '--vm-name', required=True, action='store', help='name of the vm')

    parser.add_argument('-dh', '--dest-host', required=True, action='store', help='destination host')

    args = parser.parse_args()

    if not args.password:
        args.password = getpass.getpass(prompt='Enter password')

    return args


def get_obj(content, vimtype, name):
    """
     Get the vsphere object associated with a given text name
    """
    obj = None
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)

    for c in container.view:
        if c.name == name:
            obj = c
            break
    return obj


def migrate(VM, dest_host):
    print("The current powerState is: {0}".format(VM.runtime.powerState))
    if format(VM.runtime.powerState) == "poweredOn":
        print("Attempting to power off {0}".format(VM.name))
        TASK = VM.PowerOffVM_Task()
        WaitForTask(TASK)
        print("{0}".format(TASK.info.state))
    if vim:
        relocate_spec = vim.vm.RelocateSpec(host=dest_host)
        task = VM.Relocate(relocate_spec)
        WaitForTask(task)
        print("Before PowerOn")
        WaitForTask(VM.PowerOn())
        print("PowerOn success.")


def main():
    args = get_args()
    context = None
    if hasattr(ssl, "_create_unverified_context"):
        context = ssl._create_unverified_context()

    si = SmartConnect(host=args.host, user=args.user, pwd=args.password, sslContext=context)

    atexit.register(Disconnect, si)

    content = si.RetrieveContent()

    vm = get_obj(content, [vim.VirtualMachine], args.vm_name)

    destination_host = get_obj(content, [vim.HostSystem], args.dest_host)

    migrate(vm, destination_host)


def wait_for_task(task, actionName='job', hideResult=False):
    """
    Waits and provides updates on a vSphere task
    """

    while task.info.state == vim.TaskInfo.State.running:
        time.sleep(2)

    if task.info.state == vim.TaskInfo.State.success:
        if task.info.result is not None and not hideResult:
            out = '%s completed successfully, result: %s' % (actionName, task.info.result)
            print out
        else:
            out = '%s completed successfully.' % actionName
            print out
    else:
        out = '%s did not complete successfully: %s' % (actionName, task.info.error)
        # raise task.info.error
        # print out

    return task.info.result


# Start program
if __name__ == "__main__":
    main()
