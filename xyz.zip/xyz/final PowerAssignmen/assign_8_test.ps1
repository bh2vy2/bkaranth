function GetDisks
 {    
    get-vm |select name
    $data=read-host("enter the vm")
        
    $dd=ForEach ($vm in get-vm $data){
      ($VM.Extensiondata.Guest.Disk | Select @{N="Name";E={$VM.Name}}, @{N="Capacity(MB)";
       E={[math]::Round($_.Capacity/ 1MB)}}, @{N="Free Space(MB)";E={[math]::Round($_.FreeSpace / 1MB)}}, 
       @{N="Free Space %";
      E={[math]::Round(((100* ($_.FreeSpace))/ ($_.Capacity)),0)}})}
       write-host($dd)
	} 
GetDisks   