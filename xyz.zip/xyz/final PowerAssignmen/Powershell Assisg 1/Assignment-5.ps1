#list all VM’s located on local storage along with their file name and available disk space.

function ListVMFromLocalStore 
{
	#Retrieves a list of the datastores names
	Get-Datastore |select Name
	$dataStore=read-host("Enter the Datastore name ")

	#Retrieves the local  storage information of all virtual machine in specified Datastore 
	Write-Host(Get-Datastore |where {$_.Name -match $dataStore} |Get-VM |Get-HardDisk |select Filename,CapacityGB)
}
function connect
 {
   
   echo "Enter host name ="
   $hostname=read-host hostname


   echo "Enter user name ="
   $username=read-host username

   echo "Enter The Password ="
   $password=read-host password

   try{
		# To get started, call the Connect-VIServer cmdlet and specify the IP address or DNS name of your vCenter Server system or ESX host 
	#the protocol (http or https), user name, and password
	    connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
	    write-host "you are connected to host $hostname successfully "
    }
   catch
	{
	   write-host "connection problem"
	   exit
	}
}
  connect


ListVMFromLocalStore