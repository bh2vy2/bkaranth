#list the number of vCPU�s assigned to a VM and the type of HAL installed in the O/S

function ListVMInfo()
 {
	Invoke-Expression "C:\Users\Administrator\Desktop\Assignment-2.ps1"

	
	Get-VM|select name
	
	$vMachine=read-host("Enter VM Name")
	
	Get-VM |Where {$_.Name -eq $vMachine} |Sort Name |Select Name, NumCPU,
	@{N=�OS-HAL�;E={(Get-WmiObject   -Class Win32_PnPEntity |Where { $_.ClassGuid -eq �{4D36E966-E325-11CE-BFC1-08002BE10318}� } |Select Name).Name}},
	@{N=�OperatingSystem�;E={(Get-WmiObject -Class Win32_OperatingSystem |Select Caption).Caption}}
	

}
ListVMInfo