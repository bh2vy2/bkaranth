#add additional 100GB virtual disk to Windows machine
 
function addMemory()
{

	Get-vm| select name | format-list 	 

	$vm=read-host -prompt 'enter the name of the vm '
	echo "adding 10 gb storage to '$vm' "
	Get-HardDisk -vm "$vm"| Set-HardDisk -CapacityGB 10 -Confirm:$true
	if($_.confirm -eq $true)	
	{
		echo "10 gb storage is added sucessfully"
	}
}
<#function checkConnection
{
	echo "Enter host name ="
	$hostname=read-host hostname


	echo "Enter user name ="
	$username=read-host username

	echo "Enter The Password ="
	$password=read-host password

	try{
	To get started, call the Connect-VIServer cmdlet and specify the IP address or DNS name of your vCenter Server system or ESX host 
	the protocol (http or https), user name, and password
	
		connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
		write-host "you are connected to host $hostname successfully "
		}
	catch
	{
	   write-host "connection problem "
	}
 }
 checkConnection#>
addMemory 