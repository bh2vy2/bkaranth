function getcpu{

$a=read-host "enter days"

$allvms = @()
$allhosts = @()
$hosts = Get-VMHost
$vms = Get-Vm | Where {$_.PowerState -eq "Poweredon"}  # Name powerstatues NumCPU MemoryGB

foreach($vm in $vms)
{
  $vmstat = "" | Select VmName, HostName, NumCpu, MemoryMB, MemAvg, CPUAvg
  $vmstat.VmName = $vm.name
  
  $statcpu = Get-Stat -Entity ($vm)-start (get-date).AddDays(-$a) -Finish (Get-Date)-MaxSamples 100 -stat cpu.usage.average 
  $statmem = Get-Stat -Entity ($vm)-start (get-date).AddDays(-$a) -Finish (Get-Date)-MaxSamples 100 -stat mem.usage.average 
  $cpu = $statcpu | Measure-Object -Property value -Average 
  $mem = $statmem | Measure-Object -Property value -Average 
	
	$vmstat.CPUAvg = $cpu.Average
	$vmstat.MemAvg = $mem.Average
	write-host $vmstat
	$allvms += $vmstat
		
}

	$allvms | Select VmName, HostName, NumCpu, MemoryMB, MemAvg, CPUAvg 
	
}
getcpu 