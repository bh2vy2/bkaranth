#displays disk name with its current capacity, free space and % of available free space for given virtual machine
function GetDisks
 {    
    get-vm |select name
    $data=read-host("enter the vm")
        
    $dd=ForEach ($vm in get-vm $data){
		($VM.Extensiondata.Guest.Disk | Select @{N="Name";E={$VM.Name}}, @{N="Capacity(MB)";
		E={[math]::Round($_.Capacity/ 1MB)}}, @{N="Free Space(MB)";E={[math]::Round($_.FreeSpace / 1MB)}}, 
		@{N="Free Space %";
		E={[math]::Round(((100* ($_.FreeSpace))/ ($_.Capacity)),0)}})}
		write-host($dd)
	} 
function connect
 {
   
   echo "Enter host name ="
   $hostname=read-host hostname


   echo "Enter user name ="
   $username=read-host username

   echo "Enter The Password ="
   $password=read-host password

   try{
	    connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
	    write-host "you are connected to host $hostname successfully "
    }
   catch
	{
	   write-host "connection problem"
	   exit
	}
}
  connect
GetDisks   