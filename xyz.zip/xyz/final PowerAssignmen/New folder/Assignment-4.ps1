#Number of power “On” virtual machines connected with Esxi host currently along with their names
#Number of power “Off” virtual machines connected with Esxi host currently along with their names

function getinfo
{
	get-vm|where{$_.powerstate -eq "poweredon"}
	$cnt1=(get-vm|where{$_.powerstate -eq "poweredon"}).count
	write-host ("no. of powered on VM's $cnt1")
	get-vm|where{$_.powerstate -eq "poweredoff"}
	$cnt2=(get-vm|where{$_.powerstate -eq "poweredoff"}).count
	write-host ("no. of powered off VM's $cnt2")
}

 <#function connect
 {
   
   echo "Enter host name ="
   $hostname=read-host hostname


   echo "Enter user name ="
   $username=read-host username

   echo "Enter The Password ="
   $password=read-host password

   try{
	    connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
	    write-host "you are connected to host $hostname successfully"
    }
   catch
	{
	   write-host "connection problem"
	   exit
	}
}
connect #>
getinfo