# list number of VM�s per resource pool and list Host, Cluster, Number of VMs and number of templates
function getVmCount
{ 
 
 
  Get-VMHost|Select Name,
		@{n="ResourcePool"; e={$_ | Get-ResourcePool}},	
		@{N=�Cluster�;E={Get-Cluster -VMHost $_}},
		@{N=�NumVM�;E={($_ |Get-VM).Count}}, 
		@{N=�NumTemplates�;E={($_ |Get-Template).Count}} |Sort Cluster,Name  
}		
  
 function connect
 {
   
   echo "Enter host name ="
   $hostname=read-host hostname


   echo "Enter user name ="
   $username=read-host username

   echo "Enter The Password ="
   $password=read-host password

   try{
	    connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
	    write-host "you are connected to host $hostname successfully "
    }
   catch
	{
	   write-host "connection problem"
	   exit
	}
}
  
 connect
 getVmCount