$VmInfo = Get-VM 
write-host $VmInfo
$VMS = ($VmInfo).Name 
foreach ($VM in $VMS) 
{ 
$NumberOfCPU = ($VmInfo | ? {$_.Name -eq $VM}).NumCpu
write-host $Number0fCPU
}