Get-VM | Where {$_.PowerState -eq &quot;PoweredOn&quot;} | 
Select Name, Host, NumCpu, MemoryMB, <code>
 @{N=&quot;Cpu.UsageMhz.Average&quot;;E={[Math]::Round((($_ |Get-Stat -Stat cpu.usagemhz.average -Start (Get-Date).AddHours(-24)-IntervalMins 5 -MaxSamples (12) |Measure-Object Value -Average).Average),2)}}, </code>
 @{N=&quot;Mem.Usage.Average&quot;;E={[Math]::Round((($_ |Get-Stat -Stat mem.usage.average -Start (Get-Date).AddHours(-24)-IntervalMins 5 -MaxSamples (12) |Measure-Object Value -Average).Average),2)}} `
 | Export-Csv c:\Temp\stats.csv