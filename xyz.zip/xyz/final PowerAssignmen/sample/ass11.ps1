foreach ($vmhost in get-vmhost){ 
$vms=$vmhost|get-vm 
$vmsVcpucount=($vms|Measure-Object -Property numcpu -Sum).sum 
""|Select @{N='Host';E={$vmhost.name}},@{N='cpu count';E={$vmhost.numcpu}},@{N='Actual vCPU allocated';E={$vmsVcpucount}}
 
}