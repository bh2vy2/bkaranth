
function addMemory()
{

echo "display all vm:"
Get-vm| select name | format-list 	 
echo "@@@@@@@@@@@@@@@@"
$vm=read-host -prompt 'enter the name of the vm '
echo "adding 100 gb storage to '$vm' "
Get-HardDisk -vm "$vm"| Set-HardDisk -CapacityGB 100 -Confirm:$true

if($_.confirm -eq $true)	
{
echo "100 gb storage is added sucessfully"
}
}

addMemory 