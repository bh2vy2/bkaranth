import ldap
import ldap.modlist as modlist
import requests
from tools import cli
from tools import core

requests.packages.urllib3.disable_warnings()

def ad_connect():
    ad_server = core.ad_server
    ad_username = core.ad_username
    ad_password = core.ad_password
    ldap.set_option(ldap.OPT_REFERRALS, 0)
    conn = ldap.initialize('ldap://{0}'.format(ad_server))
    conn.simple_bind_s(ad_username,ad_password)
    return conn
def setup_args():
    parser = cli.build_arg_parser()
    parser.add_argument('-g', '--newpassword', required=True,
                        help="New password of user")
    my_args = parser.parse_args()
    return cli.prompt_for_password(my_args)



def changePasswordOfUser():
    """Change password of a user in Active Directory"""
    domain = core.ad_domain
    try:
       ad_conn = ad_connect()
    except ldap.LDAPError, e:
       print "Error Occurred while connecting to AD : %s" % e
       return False
    args = setup_args()
    username = args.user
    oldpassword = args.password
    newpassword = args.newpassword
    dn="cn="+str(username)+",cn=Users,DC=cloudcoe,DC=com"

    #unicode_pass = unicode("\"" + newpassword + "\"", "iso-8859-1")
    #password_value = unicode_pass.encode("utf-16-le")
    add_pass = [(ldap.MOD_REPLACE, 'userPassword', [newpassword])]

# Replace password
    try:
        ad_conn.modify_s(dn,add_pass)
        print "Active Directory password for", username, "was set successfully!"
    except ldap.LDAPError, e:
        print "Error while changing user password: %s" % e
        return False
# Convert place-holders for modify-operation using modlist-module

    ad_conn.unbind()

changePasswordOfUser()