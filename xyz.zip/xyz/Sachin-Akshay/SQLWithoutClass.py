import requests
from tools import cli
from tools import core

import pymssql
import traceback
#import sqlBackupScript
#import sqlRestoreScript

#Connection Details
driver = "SQL Server"
server = "10.207.216.145"
user = "sa"
password = "cloud@123"

requests.packages.urllib3.disable_warnings()
def setup_args():
    parser = cli.build_arg_parser()
    parser.add_argument('-dn', '--dbName', required=False,
                        help="Name of the database which you want to create/alter/delete."
                             " If -i is not used BIOS UUID assumed.")
    parser.add_argument('-fp', '--filepath', required=False,
                        help="Fully qualified path to the SQL query file."
                             " If -i is not used BIOS UUID assumed.")
	parser.add_argument('-bfp', '--backupFilePath', required=False,
                        help="Fully qualified path to the SQL query file."
                             " If -i is not used BIOS UUID assumed.")
    parser.add_argument('-bkp', '--backupfile', required=False,
                        help="Backup File name"
                             " If -i is not used BIOS UUID assumed.")
    my_args = parser.parse_args()
    return cli.prompt_for_password(my_args)

args = setup_args()

#create connection string for database
def dbconnectionString(dbName):
	connection = pymssql.connect(host=server, user=user, password=password, database=dbName, as_dict=True)	
	
	return connection

#List databases and take backup for db on server
def run_backup(dbName, backupFilePath):
    # take backup for each database
    filename = dbName + r'_sql' + strftime("%Y%m%d%H%M%S", gmtime()) + '.bak'
    backup_db(dbName, backupFilePath, filename)
    return filename


# restore databases from backup server

#Login operations
def create_login(filepath):
	result = run_sqlfile(filepath)
	return result

def delete_login(filepath):
	result = run_sqlfile(filepath)
	return result

#sqlRestoreScript.sqlServerDbRestore(con, backupdir, DataDir,LogDir)



#Utility Functions
def readfile(filepath):
	try:
		fd = open(filepath)
		print "Read File"
		sqlFile = fd.read()
		fd.close()
		sqlCommands = sqlFile
		return sqlCommands
	except:
		traceback.print_exc()

def run_sqlfile(filepath, dbName):

	sqlCommands = readfile(filepath)
	print sqlCommands
	try:
		connection = dbconnectionString(dbName)
		# prepare a cursor object using cursor() method
		connection.autocommit = True
		cursor = connection.cursor()
		# Execute the SQL command
		cursor.execute(sqlCommands)
		print "executed command"
		# Commit your changes in the database
		connection.commit()
		cursor.close()
		del cursor
		connection.close()
		return "succesful"
	except pymssql.ProgrammingError:
		# Rollback in case there is any error
		print("Error in Sql query execution.")
		connection.autocommit = False
		return "failure"

def DatabaseExecution(dbName,sqlCommand):
	connection = dbconnectionString(dbName)
	try:
		connection.autocommit(True)
		# prepare a cursor object using cursor() method
		cursor = connection.cursor()
		# Execute the SQL command
		cursor.execute(sqlCommand)
		print "executed command"
		connection.autocommit(False)
		# Commit your changes in the database
		connection.commit()
		cursor.close()
		del cursor
		connection.close()
		return "succussful"
	except pymssql.ProgrammingError:
		# Rollback in case there is any error
		if 'CREATE' in sqlCommand:
			print("Database '"+dbName+"' already exists.")
		else:
			print("Database '" + dbName + "' does not exists.")
		connection.autocommit = False
		return "failure"

def backup_db(dbName, server_backup_path, filename):

    try:
        conn = dbconnectionString(dbName)
        cur = conn.cursor()
        fileDir = server_backup_path + filename
        print fileDir
        cur.execute('BACKUP DATABASE ? TO DISK=?',[dbName, fileDir])

        while cur.nextset():
            pass

        cur.close()
        self.conn.close()
    except:
        print 'cant backup: ' + dbName



#Create,Alter,Delete Operations
def create_database(dbName):
	sqlCommand = 'CREATE DATABASE  ' + dbName
	result = DatabaseExecution(dbName,sqlCommand)
	return result

def delete_database(dbName):
	sqlCommand = 'DROP DATABASE '+ dbName
	result = DatabaseExecution(dbName,sqlCommand)
	return result

def create_table(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

def alter_table(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

def delete_table(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

def create_storedprocedure(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

def alter_storedprocedure(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

def delete_storedprocedure(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

def create_view(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

def alter_view(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

def delete_view(filepath, dbName):
	result = run_sqlfile(filepath, dbName)
	return result

'''
Sample function calls
create_database(args.dbName)
create_table(args.filepath, args.dbName)
run_backup(args.dbName, args.backupFilePath)
'''