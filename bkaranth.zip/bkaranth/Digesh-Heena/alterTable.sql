#ALTER TABLE User DROP COLUMN DateofBirth;
ALTER TABLE User ADD DateofBirth date;
#ALTER TABLE User MODIFY COLUMN DateofBirth datetime;