import requests
import traceback
from tools import cli
#from tools import core
import MySQLdb

requests.packages.urllib3.disable_warnings()

def setup_args():
    parser = cli.build_arg_parser()

    parser.add_argument('-ho', '--host', required=True,
                        help="host nameof mySQL.")
    parser.add_argument('-user', '--user', required=True,
                        help="User Name.")
    parser.add_argument('-pwd', '--password', required=True,
                        help="Password.")
    parser.add_argument('-sc', '--scriptpath', required=True,
                        help="Name of the Script.")
    parser.add_argument('-db', '--dbname', required=True,
                        help="database name.")

    my_args = parser.parse_args()
    return my_args


args = setup_args()
def execute():
    try:
        db=MySQLdb.connect(args.host,args.user,args.password,args.dbname)
        cursor = db.cursor()
        for line in open(args.scriptpath):
            cursor.execute(line)
        db.commit()
        cursor.close()
        db.close()
    except Exception, e:
        print ("Error while execution function execute().", e)


execute()
