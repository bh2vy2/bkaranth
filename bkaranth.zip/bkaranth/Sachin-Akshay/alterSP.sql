ALTER PROCEDURE [dbo].[insertEmployee]

AS
BEGIN

INSERT INTO [dbo].[employees]
           ([last_name]
           ,[first_name]
           ,[salary])
     VALUES
           ('Orpe',
           'Akshay',
           1500000)
END

GO


