ALTER VIEW [dbo].[CreateView] AS SELECT last_name, first_name FROM dbo.employees

