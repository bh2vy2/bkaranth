CREATE PROCEDURE [dbo].[insertEmployee]

@employyeNAme varchar(50),
@employyeFName varchar(50),
@employyeSalary money

AS
BEGIN 

INSERT INTO [dbo].[employees]
           ([last_name]
           ,[first_name]
           ,[salary])
     VALUES
           (@employyeNAme,
           @employyeFName,
           @employyeSalary)
END



