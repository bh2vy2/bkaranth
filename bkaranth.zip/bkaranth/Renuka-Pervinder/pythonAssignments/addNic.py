#!/usr/bin/env python
import ssl
from pyVmomi import vim
from pyVim.connect import SmartConnect , Disconnect
import atexit
import argparse
import getpass


def get_args():

    parser = argparse.ArgumentParser(description='Arguments for talking to vCenter')

    parser.add_argument('-s' , '--host' , required=True , action='store' , help='vSphere service to connect to')

    parser.add_argument('-u' , '--user' , required=True , action='store' , help='User name to use')

    parser.add_argument('-p' , '--password' , required=True , action='store' , help='Password to use')

    parser.add_argument('-v' , '--vm-name' , required=True , action='store' , help='name of the vm')

    parser.add_argument('--uuid' , required=False , action='store' , help='vmuuid of vm')

    parser.add_argument('--port-group' , required=False , action='store' , help='port group to connect on')

    args = parser.parse_args()

    if not args.password:
        args.password = getpass.getpass(prompt='Enter password')

    return args


def get_obj(content , vimtype , name):
    obj = None
    container = content.viewManager.CreateContainerView(content.rootFolder , vimtype , True)
    for c in container.view:
        if c.name == name:
            obj = c
            break
    return obj


def add_nic(si , vm , network):
    """
    :param si: Service Instance
    :param vm: Virtual Machine Object
    :param network: Virtual Network
    """
    spec = vim.vm.ConfigSpec()
    nic_changes = [ ]

    nic_spec = vim.vm.device.VirtualDeviceSpec()
    nic_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.add

    nic_spec.device = vim.vm.device.VirtualE1000()

    nic_spec.device.deviceInfo = vim.Description()
    nic_spec.device.deviceInfo.summary = 'vCenter API test'

    nic_spec.device.backing = vim.vm.device.VirtualEthernetCard.NetworkBackingInfo()
    nic_spec.device.backing.useAutoDetect = False
    content = si.RetrieveContent()
    nic_spec.device.backing.network = get_obj(content , [ vim.Network ] , network)
    nic_spec.device.backing.deviceName = "VM Network"
    nic_spec.device.connectable = vim.vm.device.VirtualDevice.ConnectInfo()
    nic_spec.device.connectable.startConnected = True
    nic_spec.device.connectable.startConnected = True
    nic_spec.device.connectable.allowGuestControl = True
    nic_spec.device.connectable.connected = False
    nic_spec.device.connectable.status = 'untried'
    nic_spec.device.wakeOnLanEnabled = True
    nic_spec.device.addressType = 'assigned'

    nic_changes.append(nic_spec)
    spec.deviceChange = nic_changes
    vm.ReconfigVM_Task(spec=spec)
    print "NIC CARD IS ADDED SUCCESSFULLY"


def main():
    args = get_args()

    # connect this thing
    context = None
    if hasattr(ssl , "_create_unverified_context"):
        context = ssl._create_unverified_context()
    serviceInstance = SmartConnect(host=args.host , user=args.user , pwd=args.password , sslContext=context)
    # disconnect this thing
    atexit.register(Disconnect , serviceInstance)
    vm = None
    if args.vm_name:
        content = serviceInstance.RetrieveContent()
        vm = get_obj(content , [ vim.VirtualMachine ] , args.vm_name)

    if vm:
        add_nic(serviceInstance , vm , args.port_group)
    else:
        print "VM not found"

# start this thing
if __name__ == "__main__":
    main()
