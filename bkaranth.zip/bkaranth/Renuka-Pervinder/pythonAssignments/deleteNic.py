#!/usr/bin/env python
import ssl
from pyVmomi import vim
from pyVim.connect import SmartConnect, Disconnect
import atexit
import argparse
import getpass


def get_args():
    parser = argparse.ArgumentParser(
        description='Arguments for talking to vCenter')

    parser.add_argument('-s', '--host',
                        required=True,
                        action='store',
                        help='vSpehre service to connect to')

    parser.add_argument('-u', '--user',
                        required=True,
                        action='store',
                        help='User name to use')

    parser.add_argument('-p', '--password',
                        required=True,
                        action='store',
                        help='Password to use')

    parser.add_argument('-v', '--vm-name',
                        required=True,
                        action='store',
                        help='name of the vm')

    parser.add_argument('--uuid',
                        required=False,
                        action='store',
                        help='vmuuid of vm')

    parser.add_argument('--unit-number',
                        required=True,
                        action='store',
                        help='unit number')

    args = parser.parse_args()

    if not args.password:
        args.password = getpass.getpass(
            prompt='Enter password')

    return args


def get_obj(content, vimtype, name):
    obj = None
    container = content.viewManager.CreateContainerView(
        content.rootFolder, vimtype, True)
    for c in container.view:
        if c.name == name:
            obj = c
            break
    return obj


def del_nic(si, vm, nic_number):
    """ Deletes virtual NIC based on nic number
    :param si: Service Instance
    :param vm: Virtual Machine Object
    :param nic_number: Unit Number
    :return: True if success
    """
    try:
        nic_prefix_label = 'Network adapter '
        nic_label = nic_prefix_label + str(nic_number)
        virtual_nic_device = None
        for dev in vm.config.hardware.device:
            if isinstance(dev, vim.vm.device.VirtualEthernetCard) \
                    and dev.deviceInfo.label == nic_label:
                virtual_nic_device = dev

        if not virtual_nic_device:
            raise RuntimeError('Virtual {} could not be found.'.format(nic_label))
        virtual_nic_spec = vim.vm.device.VirtualDeviceSpec()
        virtual_nic_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.remove
        virtual_nic_spec.device = virtual_nic_device

        spec = vim.vm.ConfigSpec()
        spec.deviceChange = [virtual_nic_spec]
        vm.ReconfigVM_Task(spec=spec)
        return True
    except:
        raise Exception('Virtual Network adapter not found')


def main():
    args = get_args()
    # connect this thing
    context = None
    if hasattr(ssl, "_create_unverified_context"):
        context = ssl._create_unverified_context()
    serviceInstance = SmartConnect(host=args.host, user=args.user, pwd=args.password, sslContext=context)
    # disconnect this thing
    atexit.register(Disconnect, serviceInstance)
    atexit.register(Disconnect, serviceInstance)
    vm = None

    if args.vm_name:
        content = serviceInstance.RetrieveContent()
        vm = get_obj(content, [vim.VirtualMachine], args.vm_name)
        unit_no = get_obj(content, [vim.VirtualMachine], args.unit_number)
        print vm
        print unit_no

    if vm and unit_no:
        del_nic(serviceInstance, vm, int(args.unit_number))
    else:
        print "Provided information is invalid to proceed for vm nic deletion"


if __name__ == "__main__":
    main()
