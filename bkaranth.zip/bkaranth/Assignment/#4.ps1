function getinfo{
get-vm|where{$_.powerstate -eq "poweredon"}
$cnt1=(get-vm|where{$_.powerstate -eq "poweredon"}).count
write-host ("no. of powered on VM's $cnt1")
get-vm|where{$_.powerstate -eq "poweredoff"}
$cnt2=(get-vm|where{$_.powerstate -eq "poweredoff"}).count
write-host ("no. of powered off VM's $cnt2")
}
getinfo  