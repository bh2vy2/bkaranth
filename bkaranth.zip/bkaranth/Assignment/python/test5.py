import re
value = []
items=[x for x in raw_input("Enter Password:").split(',')]
for p in items:
    if len(p)<6 or len(p)>12:
        continue
    else:
        pass
    if not re.search("[a-z]",p):
        continue
    elif not re.search("[0-9]",p):
        continue
    elif not re.search("[A-Z]",p):
        continue
    elif not re.search("[$#@]",p):
        continue
    elif re.search("\s",p):
        continue
    else:
        value.append(p)
        pass
    
if len(value) == 0:		
		print("invalid Password")	
else:		
	print("Valid Password")			
	print ",".join(value)
