def invert(): 
            print("") 
            my_map = { 'red': 1, 'blue':2,'yellow':3 }
            inv_map = {v: k for k, v in my_map.items()}
            print inv_map
invert() 
