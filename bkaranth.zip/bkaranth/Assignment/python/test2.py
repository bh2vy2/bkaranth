str = raw_input("Enter string = ")
count=0
s = list()
e = list()
for i in str:
	if count %2 != 0:
			s.append(i)
			#print i
	count +=1
		
e = "".join(s)

print(e)