lines = []
str=list()
while True:
    s = raw_input("Enter String=")
    if s:
        lines.append(s.capitalize())
    else:
        break;

str = " ".join(lines)	
print(str)