function ListVMFromLocalStore {
 
Get-Datastore |select Name
$dataStore=read-host("Enter the Datastore name ")
#$path=read-host("Enter the path where you want to store details ")
#Get-Datastore |where {$_.Name -match $dataStore} |Get-VM |Get-HardDisk |select Filename,CapacityGB |Export-Csv $path} 
Write-Host(Get-Datastore |where {$_.Name -match $dataStore} |Get-VM |Get-HardDisk |select Filename,CapacityGB)
}


ListVMFromLocalStore