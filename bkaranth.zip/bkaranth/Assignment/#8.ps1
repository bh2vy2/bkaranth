 
function GetDisks {            
            
	$VMObj = Get-VM env7
	$Disk = Get-Harddisk -VM $VMObj.Name           
		

		$DiskName = $Disk.Name            

		$DiskSize = ($Disk.CapacityKB * 1024)/1GB  

		$DiskFreeSpaceSize =  ($Disk.FreeSpace / 1MB)     

		$DiskAvailablePercentCapacity=   (($DiskFreeSpaceSize / $DiskSize ) *100)
 
 


		"{0} : {1} : {2} : {3}    " -f $DiskName, $DiskFreeSpaceSize,  $Disksize, $DiskAvailablePercentCapacity
	} 
GetDisks