function list_Datastore{
$Result = Get-Datastore | Select Name, @{N="NumVM";E={@($_ | Get-VM).Count}} | Sort Name 

$Result | export-csv -Path c:\so.csv -NoTypeInformation 
}
list_Datastore