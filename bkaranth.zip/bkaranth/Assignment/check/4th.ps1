
if(Get-VM|where{$_.Powerstate -eq 'poweredon'})
{
Get-VM|where{$_.powerstate -eq 'poweredon'}|select name,Powerstate
 write-host "poweredoff machines"

}
 else
{
Get-VM|where{$_.powerstate -eq 'poweredoff'}|select name,Powerstate

}
