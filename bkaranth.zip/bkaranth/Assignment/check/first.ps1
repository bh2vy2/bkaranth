echo "Enter The Login Name ="
read username
echo "Enter The Password ="
read password

if (( $username == "pratap"  and $password == "pawar" ))
{
Write-Host("success")
}
else
{
Write-Host("not success")
}

