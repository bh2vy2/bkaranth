function first{



if($username -eq "esxiuser" -And $password -eq "cloud@123")
{
write-host "you are connected to host $hostname successfully�
}
else
{
write-error "Your connection was not successful, please verify your username name and passwordconnected"
}
}
connect-viserver -server 10.207.214.152 -protocol https -User $username -Password $password
first