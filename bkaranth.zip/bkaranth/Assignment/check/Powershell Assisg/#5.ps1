

function ListVMFromLocalStore 
{
 #Retrieves the datastores available on a vSphere server. Returns a set of datastores that correspond to the filter criteria defined by the cmdlet parameters
Get-Datastore |select Name
$dataStore=read-host("Enter the Datastore name ")
#$path=read-host("Enter the path where you want to store details ")
#Get-Datastore |where {$_.Name -match $dataStore} |Get-VM |Get-HardDisk |select Filename,CapacityGB |Export-Csv $path} 
Write-Host(Get-Datastore |where {$_.Name -match $dataStore} |Get-VM |Get-HardDisk |select Filename,CapacityGB)
}


ListVMFromLocalStore