#the number of vCPU’s on a host and in a cluster
function ListCPU
{

foreach ($vmhost in get-vmhost){ 
	$vms=$vmhost|get-vm 
	$vmsVcpucount=($vms|Measure-Object -Property numcpu -Sum).sum 
	""|Select @{N='Host';E={$vmhost.name}},@{N='cpu count';
	E={$vmhost.numcpu}},@{N='Actual vCPU allocated';
	E={$vmsVcpucount}}
 
}
}
function connect
 {
   
   echo "Enter host name ="
   $hostname=read-host hostname


   echo "Enter user name ="
   $username=read-host username

   echo "Enter The Password ="
   $password=read-host password

   try{
	    connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
	    write-host "you are connected to host $hostname successfully "
    }
   catch
	{
	   write-host "connection problem"
	   exit
	}
}
  connect
ListCPU