

function getinfo{
#Retrieves the virtual machines on a vSphere server. Returns a set of virtual machines that correspond to the filter criteria provided by the cmdlet parameters
#here cmdlet parameter is cpu state
get-vm|where{$_.powerstate -eq "poweredon"}
$cnt1=(get-vm|where{$_.powerstate -eq "poweredon"}).count
write-host ("no. of powered on VM's $cnt1")
get-vm|where{$_.powerstate -eq "poweredoff"}
$cnt2=(get-vm|where{$_.powerstate -eq "poweredoff"}).count
write-host ("no. of powered off VM's $cnt2")
}
getinfo  