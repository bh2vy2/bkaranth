echo "Enter The Login Name ="
read username
echo "Enter The Password ="
read password

if [[ $username == "pratap"  && $password == "pawar" ]]
then
  echo "u r logged in"

else
  echo "invalid Username and Password"
fi 

