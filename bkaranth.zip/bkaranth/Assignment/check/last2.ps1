
function first{

echo "Enter host name ="
$hostname=read-host hostname
echo "Enter user name ="
$username=read-host username
echo "Enter The Password ="
$password=read-host password

if($hostname -eq "10.207.214.152" -And $username -eq "esxiuser" -And $password -eq "cloud@123")
{
connect-viserver -Server $hostname -User $username -Password $password
write-host "you are connected to host $hostname successfully�
}
else
{
write-error "Your connection was not successful, please verify your username name and passwordconnected"
}
}
first