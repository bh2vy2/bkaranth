Get-VM |Where {$_.PowerState -eq �PoweredOn�} 
