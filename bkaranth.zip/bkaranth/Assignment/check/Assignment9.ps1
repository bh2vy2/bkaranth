function assignment9(){

   invoke-expression C:\Users\Administrator\Desktop\saitheja\pgm.ps1
   # $myos = SELECT * FROM Win32_PnPEntity where ClassGuid = �{4D36E966-E325-11CE-BFC1-08002BE10318}'
 #write-host "$myos"
 #Get-VM |Where {$_.PowerState -eq �PoweredOn�} |Sort Name |Select Name, NumCPU, @{N=�OSHAL�;E={(Get-WmiObject -ComputerName $_.Name-Query �SELECT * FROM Win32_PnPEntity where ClassGuid = �{4D36E966-E325-11CE-BFC1-08002BE10318}�� |Select Name).Name}}, @{N=�OperatingSystem�;E={(Get-WmiObject -ComputerName $_ -Class Win32_OperatingSystem |Select Caption).Caption}}, @{N=�ServicePack�;E={(Get-WmiObject -ComputerName $_ -Class Win32_OperatingSystem |Select CSDVersion).CSDVersion}}
 #Get-VM |Where {$_.PowerState -eq �PoweredOn�} |Sort Name |Select Name, NumCPU, @{N=�OSHAL�;E={(Get-WmiObject -ComputerName $_.Name-Query �SELECT * FROM Win32_PnPEntity where ClassGuid = �{4D36E966-E325-11CE-BFC1-08002BE10318})}'" |Select Name).Name}}, @{N=�OperatingSystem�;E={(Get-WmiObject -ComputerName $_ -Class Win32_OperatingSystem |Select Caption).Caption}}
 Get-VM |Where {$_.PowerState -eq �PoweredOn�} |Sort Name |Select Name, NumCPU, @{N=�OSHAL�;E={(Get-WmiObject -ComputerName $_.Name-Query �SELECT * FROM Win32_PnPEntity� |Select Name).Name[3]}}, @{N=�OperatingSystem�;E={(Get-WmiObject -ComputerName $_ -Class Win32_OperatingSystem |Select Caption).Caption}}, @{N=�ServicePack�;E={(Get-WmiObject -ComputerName $_ -Class Win32_OperatingSystem |Select CSDVersion).CSDVersion}}

}
assignment9