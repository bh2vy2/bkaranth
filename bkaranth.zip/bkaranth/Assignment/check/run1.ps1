echo "Enter host name ="
$hostname=read-host hostname
echo "Enter user name ="
$username=read-host username
echo "Enter The Password ="
$password=read-host password

connect-viserver -Server $hostname -User $username -Password $password
echo "connected"
