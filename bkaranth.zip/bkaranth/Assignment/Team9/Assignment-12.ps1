# list number of VM�s per resource pool and list Host, Cluster, Number of VMs and number of templates

function getVmCount
{ 
 
	#Retrieves the hosts on a vSphere server.Returns a set of hosts that correspond to cmdlet parameter.
	Get-VMHost|Select Name,
		@{n="ResourcePool"; e={$_ | Get-ResourcePool}},	
		@{N=�Cluster�;E={Get-Cluster -VMHost $_}},
		@{N=�NumVM�;E={($_ |Get-VM).Count}}, 
		@{N=�NumTemplates�;E={($_ |Get-Template).Count}} |Sort Cluster,Name  
}		
  
 function connect
 {
   
   echo "Enter host name ="
   $hostname=read-host hostname


   echo "Enter user name ="
   $username=read-host username

   echo "Enter The Password ="
   $password=read-host password

   try
   {
	
		# To get started, call the Connect-VIServer cmdlet and specify the IP address or DNS name of your vCenter Server system or ESX host 
	#the protocol (http or https), user name, and password
		connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
	    write-host "you are connected to host $hostname successfully "
    }
   catch
	{
	   write-host "connection problem"
	   exit
	}
}
  
 connect
 getVmCount