Get-VMHost|Select @{N=�Cluster�;E={Get-Cluster -VMHost $_}}, 
Name, @{N=�NumVM�;E={($_ | Get-VM).Count}} | Sort Cluster 
}
info 