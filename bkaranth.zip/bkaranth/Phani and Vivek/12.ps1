﻿cp D:\setup64.exe C:\Users\Administrator\Desktop\
$InstallerLoc ="C:\Users\Administrator\Desktop\setup64.exe"
Start-Sleep -s 7


$Switches = "/v/qn/norestart"

$Installer = Start-Process -FilePath $InstallerLoc -ArgumentList $Switches -Wait -PassThru
Write-Host "The exit code is $($Installer.ExitCode)"