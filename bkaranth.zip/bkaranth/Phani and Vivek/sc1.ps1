Connect-VIServer -Server 10.207.214.211 -User administrator@vsphere.local -Password Imscoe@1234

get-vm 'Testing_VMtools-vivek-rm' | mount-tools
