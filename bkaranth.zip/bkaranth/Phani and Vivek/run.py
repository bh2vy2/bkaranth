import requests
import traceback

requests.packages.urllib3.disable_warnings()
import os

def execute():
	from pysphere import VIServer
	server = VIServer()
	server.connect("10.207.214.211", "administrator@vsphere.local", "Imscoe@1234")
	vm = server.get_vm_by_path("[ESXi3-DataStore1] Testing_VMtools-vivek-rm.vmx")
	vm.power_on()
	print vm.get_status()
	os.system("scp "D:\vivek1\script.ps1" 10.207.216.148: "C:\Users\Administrator\Desktop\temp-tools")

execute()
