import ldap
import ldap.modlist as modlist
import requests
from tools import cli
from tools import core

requests.packages.urllib3.disable_warnings()

def ad_connect():
    ad_server = core.ad_server
    ad_username = core.ad_username
    ad_password = core.ad_password
    ldap.set_option(ldap.OPT_REFERRALS, 0)
    conn = ldap.initialize('ldap://{0}'.format(ad_server))
    conn.simple_bind_s(ad_username,ad_password)
    return conn
def setup_args():
    parser = cli.build_arg_parser()
    parser.add_argument('-j', '--surname', required=True,
                        help="Surname of the user.")
    parser.add_argument('-e', '--email', required=False,
                        help="email of user")
    parser.add_argument('-a', '--firstname', required=True,
                        help="First name of user")
    my_args = parser.parse_args()
    return cli.prompt_for_password(my_args)



def addUser():
    """Create a new user in Active Directory"""
    domain = core.ad_domain
    try:
        ad_conn = ad_connect()
    except ldap.LDAPError, e:
        print "Error Occurred while connecting to AD : %s" % e
        return False
    args = setup_args()
    surname = args.surname
    email = args.email
    firstname = args.firstname
    username = args.user
    password = args.password
	    dn="cn="+str(username)+",cn=Users,DC=cloudcoe,DC=com"

    print dn
    displayName = '%s %s [%s]' % (surname, firstname, username)

    # A dict to help build the "body" of the object
    attrs = {}
    attrs['objectclass'] =['top','person','organizationalPerson','user']
    attrs['cn'] = str(username)
    attrs['sAMAccountname'] = str(username)
    attrs['userPassword'] = str(password)
    attrs['givenName'] = str(firstname)
    #attrs['userAccountControl'] = '512'
    attrs['sn'] = str(surname)
    attrs['displayName'] = str(displayName)
    attrs['userPrincipalName'] = "%s@cloudcoe.com" % username

# Some flags for userAccountControl property
    SCRIPT = 1
    ACCOUNTDISABLE = 2
    HOMEDIR_REQUIRED = 8
    PASSWD_NOTREQD = 32
    NORMAL_ACCOUNT = 512
    DONT_EXPIRE_PASSWORD = 65536
    TRUSTED_FOR_DELEGATION = 524288
    PASSWORD_EXPIRED = 8388608

# this works!
    attrs['userAccountControl'] = str(NORMAL_ACCOUNT + ACCOUNTDISABLE)

# this does not work :-(
   # attrs['userAccountControl'] = str(NORMAL_ACCOUNT)

# Convert our dict to nice syntax for the add-function usingmodlist-module
    ldif = modlist.addModlist(attrs)
    try:
        ad_conn.add_s(dn,ldif)
    except ldap.LDAPError, e:
        print "Failed to add user to AD : %s" % e
        return False
    ad_conn.unbind()

addUser()
