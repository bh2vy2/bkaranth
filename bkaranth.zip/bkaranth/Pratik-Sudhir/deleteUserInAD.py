import ldap
import ldap.modlist as modlist
import requests
from tools import cli
from tools import core

requests.packages.urllib3.disable_warnings()

def ad_connect():
    ad_server = core.ad_server
    ad_username = core.ad_username
    ad_password = core.ad_password
    ldap.set_option(ldap.OPT_REFERRALS, 0)
    conn = ldap.initialize('ldap://{0}'.format(ad_server))
    conn.simple_bind_s(ad_username,ad_password)
    return conn
def setup_args():
    parser = cli.build_arg_parser()
    parser.add_argument('-j', '--surname', required=False,
                        help="Surname of the user.")
    parser.add_argument('-e', '--email', required=False,
                        help="email of user")
    parser.add_argument('-a', '--firstname', required=False,
                        help="First name of user")
    my_args = parser.parse_args()
    return cli.prompt_for_password(my_args)



def deleteUser():
    """Delete a user in Active Directory"""
    domain = core.ad_domain
    try:
        ad_conn = ad_connect()
    except ldap.LDAPError, e:
        print "Error Occurred while connecting to AD : %s" % e
        return False
    args = setup_args()
    username = args.user
	# Bind/authenticate with a user with apropriate rights to add

    dn="cn="+str(username)+",cn=Users,DC=cloudcoe,DC=com"

    try:
        ad_conn.delete_s(dn)
    except ldap.LDAPError, e:
        print "Cannot delete user from AD : %s" % e
        return False
    ad_conn.unbind()

deleteUser()