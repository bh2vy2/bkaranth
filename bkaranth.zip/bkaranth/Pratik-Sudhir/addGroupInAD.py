import ldap
import ldap.modlist as modlist
import requests
from tools import cli
from tools import core

requests.packages.urllib3.disable_warnings()

def ad_connect():
    ad_server = core.ad_server
    ad_username = core.ad_username
    ad_password = core.ad_password
    ldap.set_option(ldap.OPT_REFERRALS, 0)
    conn = ldap.initialize('ldap://{0}'.format(ad_server))
    conn.simple_bind_s(ad_username,ad_password)
    return conn

def setup_args():
    parser = cli.build_arg_parser()
    parser.add_argument('-g', '--groupname', required=True,
                        help="Name of the group")
    parser.add_argument('-d', '--description', required=True,
                        help="Description of the group")
    my_args = parser.parse_args()
    return cli.prompt_for_password(my_args)

def addGroup():
    """Create a new Group in Active Directory"""
    domain = core.ad_domain

    try:
        ad_conn = ad_connect()
    except Exception, w:
        print w

    args = setup_args()
    groupname = args.groupname
    description = args.description
    #Open a connection

    # The dn of our new entry/object
    #dn="cn=%s,%s" % ("barath","cloud@coe")
    dn="cn="+str(groupname)+",cn=Users,DC=cloudcoe,DC=com"

    print dn

    # A dict to help build the "body" of the object
    attrs = {}
    attrs['objectclass'] =['top','Group']
    attrs['cn'] = str(groupname)
    attrs['description'] = str(description)

    # Convert our dict to nice syntax for the add-function usingmodlist-module
    ldif = modlist.addModlist(attrs)

    try:
        ad_conn.add_s(dn,ldif)
    except Exception, e:
        print e

    ad_conn.unbind()

addGroup()