Get-Datastore | Select-Object Name, 
 @{N="VMFS version";E={$_.ExtensionData.Info.Vmfs.Version}},
 @{N="BlocksizeMB";E={$_.ExtensionData.Info.Vmfs.BlockSizeMB}},
@{N="MPP";E={ $esx = Get-View $_.ExtensionData.Host[0].Key
 $_.ExtensionData.Info.Vmfs.Extent | %{
 Get-ScsiLun -CanonicalName $_.DiskName -VmHost $esx.Name | 
Select -ExpandProperty MultipathPolicy }get
 }}   