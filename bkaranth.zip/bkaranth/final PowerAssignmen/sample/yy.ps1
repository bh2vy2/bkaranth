Param( 
            
                [string]$myserverip = $( Read-Host "Input Ip, please" ), 
                
                [string]$myusername = $( Read-Host "Input Username, please" ), 
                [string]$mypassname = $( Read-Host "Input password, please" ) 
                
     )
 

function getinfo{


if(connect-VIserver $myserverip -user $myusername -password $mypassname) 
{
    write-output "you are connected to $myserverip successfully" 
} 
else 
{ 
write-output "failed" 
}
}