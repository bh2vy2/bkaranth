
function getdetails{
                   Get-VM | Where {$_.PowerState -eq "PoweredOn"} | 
                   Select Name, VMHost, NumCpu, MemoryMB, 
                   @{N="Cpu.UsageMhz.Average";E={[Math]::Round((($_ |Get-Stat -Stat cpu.usagemhz.average -Start (Get-Date).AddHours(-24)-IntervalMins 5 -MaxSamples (12) |Measure-Object Value -Average).Average),2)}}, 
                   @{N="Mem.Usage.Average";E={[Math]::Round((($_ |Get-Stat -Stat mem.usage.average -Start (Get-Date).AddHours(-24)-IntervalMins 5 -MaxSamples (12) |Measure-Object Value -Average).Average),2)}} `
                   | Export-Csv C:\Users\Administrator\Desktop\completed\report.csv 
}
getdetails 
