echo "enter the host name"
$host =read-host "enter"


if("$host" -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}" )
{
    echo sucess
} 




