echo "Enter host name =" 
$hostname=read-host hostname


if (($hostname -eq "10.207.214.152") -Or($hostname -eq "10.207.214.153"))
 { 
   
echo "Enter user name =" 
$username=read-host username 
echo "Enter The Password =" 
$password=read-host password
if(($username -eq "esxiuser") -And ($password -eq "cloud@123"))
{ 
 
        connect-viserver -Server $hostname -User $username -Password $password 
        write-host "you are connected to host $hostname successfully� 
   
 
 } 
else 
{ 
 Write-Output "Invalid Credentials" 
} 
} 
else 
{ 
 Write-Output "Please enter correct hostname of 14 characters." 
}