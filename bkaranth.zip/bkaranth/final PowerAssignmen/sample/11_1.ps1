Get-VMHost |Select name,
		@{n="ResourcePool"; e={$_ | Get-ResourcePool}},	
		@{N=�Cluster�;E={Get-Cluster -VMHost $_}},Name, 
		@{N=�NumVM�;E={($_ |Get-VM).Count}}, 
		@{N=�NumTemplates�;E={($_ |Get-Template).Count}} |Sort Cluster,Name

