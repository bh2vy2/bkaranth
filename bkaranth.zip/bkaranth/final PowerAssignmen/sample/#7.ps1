function info
{
Get-VMHost|Select Name, @{N=�NumVM�;E={($_ | Get-VM).Count}} 
}
info 