#add additional 100GB virtual disk to Windows machine

function addMemory()
{
	Get-vm| select name | format-list 	
 
	$vm=read-host -prompt 'enter the name of the vm '
	echo "adding 100 gb storage to '$vm' "
	Get-HardDisk -vm "$vm"| Set-HardDisk -CapacityGB 100 -Confirm:$true

	if($_.confirm -eq $true)	
	{
			echo "100 gb storage is added sucessfully"
	}
}

addMemory