#list all VM’s located on local storage along with their file name and available disk space.

function ListVMFromLocalStore {
 
	Get-Datastore |select Name
	$dataStore=read-host("Enter the Datastore name ")
	#$path=read-host("Enter the path where you want to store details ")
	#Get-Datastore |where {$_.Name -match $dataStore} |Get-VM |Get-HardDisk |select Filename,CapacityGB |Export-Csv $path} 
	Write-Host(Get-Datastore |where {$_.Name -match $dataStore} |Get-VM |Get-HardDisk |select Filename,CapacityGB)
}
function connect
 {
   
   echo "Enter host name ="
   $hostname=read-host hostname


   echo "Enter user name ="
   $username=read-host username

   echo "Enter The Password ="
   $password=read-host password

   try{
	    connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
	    write-host "you are connected to host $hostname successfully "
    }
   catch
	{
	   write-host "connection problem"
	   exit
	}
}
  connect


ListVMFromLocalStore