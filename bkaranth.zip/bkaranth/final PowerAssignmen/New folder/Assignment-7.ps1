 #lists how many VM�s were on each host.
 function ListVm
{
	Get-VMHost|Select Name, @{N=�NumVM�;E={($_ | Get-VM).Count}} 
}
function connect
 {
   
   echo "Enter host name ="
   $hostname=read-host hostname


   echo "Enter user name ="
   $username=read-host username

   echo "Enter The Password ="
   $password=read-host password

   try{
	    connect-viserver -Server $hostname -User $username -Password $password -ErrorAction Stop
	    write-host "you are connected to host $hostname successfully "
    }
   catch
	{
	   write-host "connection problem"
	   exit
	}
}
  connect
ListVm 